//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var a=[1,2,3,4,5]
print(a[1])

a.append(3)
print(a[3])


var b=[6,7,8,9,10]

a=a+b


for i in a
{
    print(i)
}

var c:[ Int]!
print(a.count)
//c?.append(8)
print(c?.count ?? 0)

print("---new---")
for i in a[5...]
{
    print(i)
}

var e=a[2...5]
print("---new---")
for i in e
{
    print(i)
}
print("---one---")
print(a[2])
print("---two---")
print(e[2])

e[2]=90000
print("---three---")
print(a[2])
print("---four---")
print(e[2])

print("size of e\(e.count)")


var threedoubles=Array(repeating: 0.0,count:3)
for (k,v) in a.enumerated()
{
    print("index:\(k)-->\(v)")
}






































