//: Playground - noun: a place where people can play

import UIKit



var a = ["name":"Pritesh", "city":"Toronto"]

print("Keys/Values")
for (k, v) in a{
    print("\(k)-->\(v)")
}

a["job"] = "Software Developer"

print("Only Keys")
for k in a.keys{
    print("\(k)")
}

print("Only Values")
for v in a.values{
    print("\(v)")
}


var str="hello😇"


var A="\u{24}"
var B="\u{1f496}"

print (A,B)


let longstring = """
abfjsfsk bfsb
flehildnlnsl
lfsjkdohnsdl
""";

print(longstring)


print("\"hello\",srikanth")


var s=string()
s="welcome to lambton"
































