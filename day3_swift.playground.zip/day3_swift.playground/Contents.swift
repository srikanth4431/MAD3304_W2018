//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func display(name:String)
{
    print("welcome,\(name)")

}
display(name:"srikanth")


func display(number n:Int)
{
 for i in 1...n
 {
    print(i)
    }
}

display(number:5)





func add(_ a: Int, b: Int)
{
    print("Sum : \(a+b)")
}

add(10, b:20)

func sum(of a: Int, and b: Int)
{
    print("Add : \(a+b)")
}

sum(of:10, and:20)

func Display(number n: Int)
{
    for i in 1...n
    {
        print(i)
    }
}

display(number:5)


func greet()->String
{
    return " welcome to lambton "
}

var s = greet()
print(s)
print(greet())

func add(_ a: Int,_  b: Int)->Int
{
    return (a+b)
}

func add(_ a: Float,_ b: Float)-> Float
{
    return (a+b)
}

func add(_ a: String, _ b: String)-> String
{
    return a+b
}

print(add(1,2))
print(add(1,1.2))
print(add("hello"," world"))

//Return Tuples
func swip(a: String, b: String) -> (String, String)
{
    return (b, a)
}

let x = swip(a: "Pritesh", b: "Patel")
print(x.0, x.1)

func swip(a: Int, b: Int) -> (a:Int, b:Int)
{
    return (b, a)
}

let z = swip(a: 100, b: 200)
print(z.a, z.b)


//passing array
func addvalues(arr:[Int])-> Int
{
    var add=0
    for i in arr
    {
        add=add+i
    }
return add
}


print(addvalues(arr:[2,3,2]))
var na=[100,200,50,140]

print(addvalues(arr:na))

//passing array and returning tuples
func findMinMax(arr:[Int])-> (min:Int,max:Int)
{
    return (arr.min() ?? 0,arr.max() ?? 0)
}

var minmax = findMinMax(arr: [200,30,50,60,800,100])
print(minmax.min, minmax.max)

//default parameter
func sii(amount:Double,noofyears:Int=5,rateofinterest:Float=0.5)->Double
{
    return(amount*Double(noofyears)*Double(rateofinterest))
}

print(sii(amount:1000,rateofinterest:1.5))
//print(sii(amount:1000,noofyears:5,rateofinterest:1.25))



//default parameter without label
func siii(_ amount:Double,_ noofyears:Int=5,_ rateofinterest:Float=0.5)->Double
{
    return(amount*Double(noofyears)*Double(rateofinterest))
}

print(siii(1000,0,1.5))
print(siii(1000,5,1.25))


//iout example
func swaptwoInts(_ a:inout Int,_ b:inout Int)

{
    let temporaryA=a
    a=b
    b=temporaryA
}

var x1=100
var x2=200


print(x1,x2)
swaptwoInts(&x1,&x2)
print(x1,x2)

//inbuilt function provided by swift library
swap(&x1,&x2)
printvalues(a:1,2,50,30,5000,30,50,60)




